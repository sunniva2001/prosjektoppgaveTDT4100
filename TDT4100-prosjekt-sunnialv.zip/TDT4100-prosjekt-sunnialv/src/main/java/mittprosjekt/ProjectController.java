package mittprosjekt;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

public class ProjectController {

    @FXML
    private UNOGame game;

    @FXML
    private GridPane gridpane = new GridPane();

    @FXML
    private Label topCardLabel;

    @FXML
    private Label userInfoLabel;

    @FXML
    private Label compNumbCardsLabel;

    @FXML
    private Label UNOLabel;

    
    //oppstart:
    @FXML
    private void initialize() {
        game = new UNOGame();

        this.game.getPlayersCardHand().sortCards();
        
        printCardButtons();

        topCardLabel.setText(this.game.getCurrentTopCard().toString());

        userInfoLabel.setText("Your turn!");

        setCompLabelText(this.game.getComputersCardHand().getCardCount());

    }

    //brukerinteraksjon:
    @FXML
    private void handleDrawButtonClick() {
        if (this.game.getPlayersCardHand().getCardCount() < 36 && this.game.getCurrentPlayer() == this.game.getPlayersCardHand()) {
            this.game.getPlayersCardHand().drawCard();

            printCardButtons();
        }
        else{
            userInfoLabel.setText("Can't draw card");
        }
    }

    @FXML
    private void handleUNOButtonClick() {
        if (this.game.getPlayersCardHand().getCardCount() == 1 && this.game.getCurrentPlayer() == this.game.getComputersCardHand()) {
            this.game.setUNOButtonPressed(true);
            UNOLabel.setText("Pressed");
        }
        else{
            UNOLabel.setText("Can't press this now");
        }

        
    }

    @FXML
    private void handleSaveButtonClick() {
        try {
            this.game.writeCardContainerToFile(this.game.getPlayersCardHand(), "PlayersCardHand.txt");
            this.game.writeCardContainerToFile(this.game.getComputersCardHand(), "ComputersCardHand.txt");
            this.game.writeCardContainerToFile(this.game.getCardDeck(), "CardDeck.txt");
            this.game.writeGameDataToFile();

            userInfoLabel.setText("Game saved!");
        } catch (Exception e) {
            userInfoLabel.setText("Unable to save game");
        }
    }

    @FXML
    public void handleResumeButtonClick(){
        try {
            this.game.getCardContainerFromFile(this.game.getPlayersCardHand(), "PlayersCardHand.txt");
            this.game.getCardContainerFromFile(this.game.getComputersCardHand(), "ComputersCardHand.txt");
            this.game.getCardContainerFromFile(this.game.getCardDeck(), "CardDeck.txt");
            this.game.getGameDataFromFile();

            printCardButtons();
            topCardLabel.setText(this.game.getCurrentTopCard().toString());
            setCompLabelText(this.game.getComputersCardHand().getCardCount());
            if (this.game.getCurrentPlayer() == this.game.getComputersCardHand()) {
                userInfoLabel.setText("Computer's turn!");
            }

        } catch (Exception e) {
            userInfoLabel.setText("Unable to resume game");
        }
    }

    @FXML
    private void handleComputerPlays(){
        if (this.game.getCurrentPlayer() == this.game.getComputersCardHand()) {

            userInfoLabel.setText("");
            this.game.computerPlays();
            topCardLabel.setText(this.game.getCurrentTopCard().toString());
            setCompLabelText(this.game.getComputersCardHand().getCardCount());

            this.game.setCurrentPlayer(this.game.getPlayersCardHand());

            if (this.game.isWinner(this.game.getComputersCardHand())) {
                userInfoLabel.setText("THE COMPUTER WON!");
            }

            printCardButtons();
        }
    }

    @FXML
    private void handlePlayCard(UNOCard card){
        if (this.game.getCurrentPlayer() == this.game.getPlayersCardHand()) { //hvis det er spilleren sin tur
            this.game.getPlayersCardHand().playCard(card);
            UNOLabel.setText("");
            
            if (this.game.getPlayersCardHand().playCard(card) != null) {
                topCardLabel.setText(card.toString());
                userInfoLabel.setText("");

                this.game.setCurrentPlayer(this.game.getComputersCardHand());

                //Spiller glemt å trykke på UNO-knappen, må trekke 3 kort
                if (this.game.isWinner(this.game.getPlayersCardHand())) {
                    if (this.game.getUNOButtonPressed() == true) {
                        userInfoLabel.setText("YOU WON!!!!");
                    }
                    else{
                        userInfoLabel.setText("You did not press UNO");
                        this.game.getPlayersCardHand().drawCard();
                        this.game.getPlayersCardHand().drawCard();
                        this.game.getPlayersCardHand().drawCard();

                        printCardButtons();
                    }
                }

                setCompLabelText(this.game.getComputersCardHand().getCardCount());
            }
            else{
                userInfoLabel.setText("You can't play this card");
            }

            printCardButtons();
        }
        else{
            userInfoLabel.setText("Not your turn! Press computerPlays");
        }
    }

    //hjelpemetoder:
    @FXML
    private void printCardButtons(){
        
        //fjerner alle knapper, før man printer på nytt
        gridpane.getChildren().clear();


        //kan max ha 36 kort på hånden (ikke plass til flere på skjermen)
        if (this.game.getPlayersCardHand().getCardCount() <= 36){
            for (int i = 0; i < this.game.getPlayersCardHand().getCardCount(); i++) {
                if (i < 12) {
                    Button button = new Button(this.game.getPlayersCardHand().getCard(i).toString());
                    int temp = i;
                    button.setOnAction(event -> handlePlayCard(this.game.getPlayersCardHand().getCard(temp)));
                    gridpane.add(button, i, 0);
                }
                else if (i >= 12 && i < 24){
                    Button button = new Button(this.game.getPlayersCardHand().getCard(i).toString());
                    int temp = i;
                    button.setOnAction(event -> handlePlayCard(this.game.getPlayersCardHand().getCard(temp)));
                    gridpane.add(button, i-12, 1);
                }
                else{
                    Button button = new Button(this.game.getPlayersCardHand().getCard(i).toString());
                    int temp = i;
                    button.setOnAction(event -> handlePlayCard(this.game.getPlayersCardHand().getCard(temp)));
                    gridpane.add(button, i-24, 2);
                }
            }            
        }
    }

    @FXML
    private void setCompLabelText(int numbOfCards){
        compNumbCardsLabel.setText("Computer has " + numbOfCards + " cards left");
    }
}

