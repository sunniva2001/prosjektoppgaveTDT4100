package mittprosjekt;

public class UNOCard {

    private char colour;
    private int number;
    private static final char[] availColours = {'G', 'R', 'Y', 'B'}; //legg til 'W' for wild cards

    //konstruktør
    public UNOCard(char colour, int number){
        setColour(colour);
        setNumber(number);
    }

    //setters--------------------------------------------------------------------------------
    public void setColour(char colour){
        if(!isValidColour(colour)){
            throw new IllegalArgumentException("Invalid colour");
        }
        this.colour = colour;
    }

    public void setNumber(int number){
        if(!isValidNumber(number)){
            throw new IllegalArgumentException("Invalid number");
        }
        this.number = number;
    }
    //-------------------------------------------------------------------------------
    


    //getters----------------------------------------------------------------------------
    public char getColour(){
        return this.colour;
    }

    public int getNumber(){
        return this.number;
    }
    //-------------------------------------------------------------------------------------


    
    //hjelpemetoder m.m.--------------------------------------------------------------------
    private boolean isValidColour(char colour){
        for (char c : availColours){
            if (colour == c){
                return true;
            }
        }
        return false;
    }

    private boolean isValidNumber(int number){
        return (number >= 0 && number <= 9);
    }

    @Override
    public String toString() {
        return this.colour + "" + this.number;
    }

}
