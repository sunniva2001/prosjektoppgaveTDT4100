package mittprosjekt;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;


public class UNOCardContainer { //CardDeck og CardHand arver fra denne klassen
    protected UNOGame game;
    protected List<UNOCard> cards = new ArrayList<UNOCard>();
    protected static final char[] availColours = {'G', 'R', 'Y', 'B'};

    public class UNOCardComparator implements Comparator<UNOCard>{
        @Override
        public int compare(UNOCard c1, UNOCard c2) {
    
            List<Character> colours = new ArrayList<>();
            colours.add('B');
            colours.add('G');
            colours.add('R');
            colours.add('Y');
    
            if (c1.getColour() == c2.getColour()) {
                return c1.getNumber() - c2.getNumber();
            }
            else{
                return colours.indexOf(c1.getColour()) - colours.indexOf(c2.getColour());
            }
        }
    }


    //konstruktør
    public UNOCardContainer(){
        
    }

    //setters
    public void setGame(UNOGame game){
        this.game = game;
    }
    
    //getters
    public int getCardCount(){
        return this.cards.size();
    }

    public UNOCard getCard(int n){
        if(n < 0 || n >= cards.size()){
            throw new IllegalArgumentException("Invalid index");
        }
        return cards.get(n);
    }

    public UNOGame getGame(){
        return this.game;
    }

    public List<UNOCard> getCards(){
        return this.cards;
    }

    //andre metoder
    public void addCard(UNOCard card){
        this.cards.add(card);
    }

    public void removeCard(UNOCard card){
        if (this.cards.contains(card)){
            this.cards.remove(card);
        }
    }


    @Override
    public String toString() {
        String cardDeckString = "";
        for (UNOCard c : cards) {
            cardDeckString += c;
            cardDeckString += ", ";
        }
        return cardDeckString;
    }
}
