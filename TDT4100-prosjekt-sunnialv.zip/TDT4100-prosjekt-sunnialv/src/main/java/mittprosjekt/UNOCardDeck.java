package mittprosjekt;

import java.util.Collections;

public class UNOCardDeck extends UNOCardContainer{ 

    public void deal(UNOCardHand cardHand, int n){ //tar inn spiller og antall kort
        if (this.getCardCount() >= n){
            for (int i = 0; i < n; i++) {
                UNOCard currentCard = this.cards.get(i);
                cardHand.addCard(currentCard);
                this.cards.remove(currentCard);
            }
        }
        else{
            throw new IllegalStateException("Not enough cards in deck");
        }
    }

    public void ShuffleRandomly(){
        Collections.shuffle(this.cards);
    }

    public void setFullUNODeck(){
        for (char c : availColours) {
            for (int i = 0; i <= 9; i++) {
                UNOCard card = new UNOCard(c, i);
                this.cards.add(card);
                if (i != 0){ //skal bare være 1 null av hver farge
                    this.cards.add(card);
                }
            }
        }
    }

    public static void main(String[] args) {
        
    }
}


