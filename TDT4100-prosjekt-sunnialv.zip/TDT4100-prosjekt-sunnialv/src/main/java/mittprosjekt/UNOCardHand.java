package mittprosjekt;

import java.util.Collections;

public class UNOCardHand extends UNOCardContainer{

    public UNOCard playCard(UNOCard card){
        if (this.game.getCurrentTopCard().getColour() == card.getColour() || this.game.getCurrentTopCard().getNumber() == card.getNumber()) {
            
            this.game.addToPlayPile(card);
            this.cards.remove(card);
            this.game.setCurrentTopColour(card.getColour());
            this.game.setCurrentTopCard(card);
            
            return card;
        }
        return null;
    }

    public UNOCard drawCard() {
        if (this.game.getCardDeck().getCardCount() > 0) {
            UNOCard currentCard = this.game.getCardDeck().getCard(0);
            this.cards.add(currentCard);
            this.game.getCardDeck().removeCard(currentCard);
            return currentCard;
        }
        else{ //hvis trekkbunken er tom
            this.game.getCardDeck().setFullUNODeck();

            for (UNOCard c : this.game.getPlayersCardHand().getCards()) {
                this.game.getCardDeck().removeCard(c);
            }

            for (UNOCard c : this.game.getComputersCardHand().getCards()) {
                this.game.getCardDeck().removeCard(c);
            }

            this.game.getCardDeck().removeCard(this.game.getCurrentTopCard());

            this.game.getCardDeck().ShuffleRandomly();

            this.drawCard();
        }
        return null;
    }

    public void sortCards(){ //sorterer kortene etter farge og så tall
        Collections.sort(this.cards, new UNOCardComparator());
    }
}
