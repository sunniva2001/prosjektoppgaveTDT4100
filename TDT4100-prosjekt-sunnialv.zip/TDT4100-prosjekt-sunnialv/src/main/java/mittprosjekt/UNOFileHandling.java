package mittprosjekt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UNOFileHandling {

    private UNOGame game;


    public void setGame(UNOGame game){
        this.game = game;
    }


    public void writeCardContainerToFile(UNOCardContainer cardContainer, String filename)  throws FileNotFoundException{ //må ha en try/catch i kontrolleren
        PrintWriter writer = new PrintWriter(filename);

            for (UNOCard card : cardContainer.getCards()) {
                writer.println(card);
            }

            writer.flush();
            writer.close();
    }

    
    public void getCardContainterFromFile(UNOCardContainer cardContainer, String filename) throws FileNotFoundException{ 
        Scanner scanner = new Scanner(new File(filename));

        cardContainer.cards.clear(); //fjerner eventuelle andre kort
        
        while (scanner.hasNextLine()){
            String line = scanner.nextLine();

            int number = Character.getNumericValue(line.charAt(1));

            UNOCard card = new UNOCard(line.charAt(0), number); 

            cardContainer.addCard(card);
        }

        scanner.close();
    }

    public void writeGameDataToFile() throws FileNotFoundException{
        PrintWriter writer = new PrintWriter("GameData.txt");

        writer.println(this.game.getCurrentTopCard());

        //lagrer også hvem sin tur det er
        if (this.game.getCurrentPlayer() == this.game.getPlayersCardHand()) {
            writer.println("player");
        }
        else if (this.game.getCurrentPlayer() == this.game.getComputersCardHand()) {
            writer.println("computer");
        }

        writer.flush();
        writer.close();
    }

    public void getGameDataFromFile() throws FileNotFoundException{ 
        Scanner scanner = new Scanner(new File("GameData.txt"));
        List<String> temp = new ArrayList<String>();

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            temp.add(line);
        }

        int number = Character.getNumericValue(temp.get(0).charAt(1));
        UNOCard card = new UNOCard(temp.get(0).charAt(0), number);
        this.game.setCurrentTopCard(card);
        
        if (temp.get(1).equals("player")){
            this.game.setCurrentPlayer(this.game.getPlayersCardHand());
        }
        else if (temp.get(1).equals("computer")){
            this.game.setCurrentPlayer(this.game.getComputersCardHand());
        }

        scanner.close();
    }

    public static void main(String[] args) {
    
    }
}
