package mittprosjekt;

import java.io.FileNotFoundException;

public class UNOGame {

    private static final char[] availColours = {'G', 'R', 'Y', 'B'};

    private UNOCardDeck cardDeck;
    private UNOCardHand playersCardHand;
    private UNOCardHand computersCardHand;
    private UNOCardContainer playPile = new UNOCardContainer();

    private boolean UNOButtonPressed = false;
    
    private UNOCard currentTopCard;
    private UNOCardHand currentPlayer;
    private char currentTopColour;

    private UNOFileHandling fileHandler;

    //konstruktør
    public UNOGame(){

        cardDeck = new UNOCardDeck();
        playersCardHand = new UNOCardHand();
        computersCardHand = new UNOCardHand();

        fileHandler = new UNOFileHandling();
        fileHandler.setGame(this);

        cardDeck.setFullUNODeck();
        cardDeck.ShuffleRandomly();

        //deler ut 7 kort til spilleren og datamskinen
        this.cardDeck.deal(playersCardHand, 7);
        playersCardHand.setGame(this);
        this.cardDeck.deal(computersCardHand, 7);
        computersCardHand.setGame(this);

        //"snur" det øverste kortet i draw-pilen
        this.currentTopCard = this.cardDeck.getCard(0);
        this.cardDeck.removeCard(this.currentTopCard);
        this.currentTopColour = this.currentTopCard.getColour();

        this.currentPlayer = this.playersCardHand;

    }

    public void addToPlayPile(UNOCard card){
        this.playPile.addCard(card);
    }

    public boolean isWinner(UNOCardHand player){
        return player.getCardCount() == 0;
    }

    //hjelpemetode
    public boolean computerHasValidCard(){
        return computersCardHand.getCards()
        .stream()
        .anyMatch(card -> card.getColour() == this.currentTopColour || card.getNumber() == this.currentTopCard.getNumber());

    }

    public UNOCard computerPlays(){ //kjører hele computer sin tur

        //while-løkke som trekker kort frem til computer har et lovlig kort
        while (!computerHasValidCard()) {
            this.computersCardHand.drawCard();
        }

        //computer legger så på det første lovlige kortet den har
        for (UNOCard card : computersCardHand.getCards()) {
            if (card.getColour() == this.currentTopColour || card.getNumber() == this.currentTopCard.getNumber()) {
                computersCardHand.playCard(card);
                return card;
            }
        }
        return null; //skal ikke intreffe
    }
    

    //setters----------------------------------------------------------------------------------------
    public void setCurrentTopColour(char colour){
        if(!isValidColour(colour)){
            throw new IllegalArgumentException("Invalid colour");
        }
        this.currentTopColour = colour;
    }

    public void setCurrentTopCard(UNOCard card){
        this.currentTopCard = card;
    }

    public void setUNOButtonPressed(boolean b){
        this.UNOButtonPressed = b;
    }

    public void setCurrentPlayer(UNOCardHand player){
        if (player == this.computersCardHand || player == playersCardHand){
            this.currentPlayer = player;
        }
    }
    //---------------------------------------------------------------------------------------------------



    //getters------------------------------------------------------------------------------------------
    public UNOCard getCurrentTopCard(){
        return this.currentTopCard;
    }

    public char getCurrentTopColour(){
        return this.currentTopColour;
    }

    public UNOCardHand getOpponent(UNOCardHand cardHand){
        if (cardHand == playersCardHand) {
            return computersCardHand;
        }
        else{
            return playersCardHand;
        }
    }

    public UNOCardHand getCurrentPlayer(){
        return this.currentPlayer;
    }

    public UNOCardDeck getCardDeck(){
        return this.cardDeck;
    }

    public UNOCardHand getPlayersCardHand(){
        return playersCardHand;
    }

    public UNOCardHand getComputersCardHand(){
        return computersCardHand;
    }

    public boolean getUNOButtonPressed(){
        return UNOButtonPressed;
    }

    //---------------------------------------------------------------------------------------------------------



    //hjelpemetoder---------------------------------------------------------------------------------------------
    private boolean isValidColour(char colour){
        for (char c : availColours){
            if (colour == c){
                return true;
            }
        }
        return false;
    }
    //---------------------------------------------------------------------------------------------------------




    //lagre spill - skrive til/lese fra fil ----------------------------------------------------------------------------------------------

    public void writeCardContainerToFile(UNOCardContainer cardContainer, String filename){
        try {
            this.fileHandler.writeCardContainerToFile(cardContainer, filename);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void getCardContainerFromFile(UNOCardContainer cardContainer, String filename){
        try {
            this.fileHandler.getCardContainterFromFile(cardContainer, filename);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void writeGameDataToFile(){
        try {
            this.fileHandler.writeGameDataToFile();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void getGameDataFromFile(){
        try {
            this.fileHandler.getGameDataFromFile();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
    
    }
}
