package exampleproject;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import mittprosjekt.UNOCard;
import mittprosjekt.UNOGame;

public class UNOCardContainerTest {
    
    UNOGame game;
    int expectedNumbPlayersCards;
    int expectedNumbCardsInDeck;
    UNOCard expectedDrawnCard;

    UNOCard Y1;
    UNOCard Y2;
    UNOCard G1;

    @BeforeEach
    public void setUp() {
		game = new UNOGame();
        expectedNumbPlayersCards = 7;
        expectedNumbCardsInDeck = 76;
        expectedDrawnCard = this.game.getCardDeck().getCard(0);
        Y1 = new UNOCard('Y', 1);
        Y2 = new UNOCard('Y', 2);
        G1 = new UNOCard('G', 1);
	}
    
    
    @Test
    @DisplayName("Check that drawCard-method draws expected card from deck")
    public void checkDrawCard(){
        UNOCard card = this.game.getPlayersCardHand().drawCard();

        
        assertEquals(expectedNumbPlayersCards + 1, this.game.getPlayersCardHand().getCardCount(), "Card was not added to players card hand");
        //-15 siden det er delt ut 7 til hver spiller og snudd ett kort til toppkort
        assertEquals(expectedNumbCardsInDeck - 1 - 15, this.game.getCardDeck().getCardCount(), "Card not removed from deck");
        assertEquals(expectedDrawnCard, card, "Does not draw top card from deck");
    }


    @Test
    @DisplayName("Check that playCard-method works as expected")
    public void checkPlayCard(){

        //sjekker først at det funker for samme farge
        this.game.setCurrentTopCard(Y1);
        this.game.getPlayersCardHand().addCard(Y2);
        this.game.getPlayersCardHand().playCard(Y2);

        assertTrue(this.game.getCurrentTopCard() == Y2, "Card not added as new top card");
        assertEquals(expectedNumbPlayersCards, this.game.getPlayersCardHand().getCardCount(), "Card not removed from players card hand");

        //sjekker så at det funker for samme tall
        this.game.setCurrentTopCard(Y1);
        this.game.getPlayersCardHand().addCard(G1);
        this.game.getPlayersCardHand().playCard(G1);

        assertTrue(this.game.getCurrentTopCard() == G1, "Card not added as new top card");
        assertEquals(expectedNumbPlayersCards, this.game.getPlayersCardHand().getCardCount(), "Card not removed from players card hand");
    }

    @Test
    @DisplayName("Check that the deal-method throws exception if not enough cards left")
    public void checkDeal(){

        assertThrows(IllegalStateException.class, () -> {
            this.game.getCardDeck().deal(this.game.getPlayersCardHand(), 500);
        }, "Expected exception when surpassing numb of cards in deck");
        
    }

}
