package exampleproject;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import mittprosjekt.UNOCard;

public class UNOCardTest {
    
    @Test
    @DisplayName("Invalid colour and number throws exception")
    public void testCardConstructor() {
        assertThrows(IllegalArgumentException.class, () -> {
            new UNOCard('X', 5);
        }, "Expected exception when passing invalid color");

        assertThrows(IllegalArgumentException.class, () -> {
            new UNOCard('B', 35);
        }, "Expected exception when passing invalid color");
    }
}
