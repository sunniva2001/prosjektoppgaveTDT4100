package exampleproject;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import mittprosjekt.UNOCard;
import mittprosjekt.UNOCardContainer;
import mittprosjekt.UNOGame;

public class UNOFileMangTest {

    UNOCardContainer cardContainer;
    UNOGame game;
    String filename;
    UNOCard B4;
    UNOCard G7;
    UNOCard R9;
    
    @BeforeEach
    public void setup(){
        cardContainer = new UNOCardContainer();
        game = new UNOGame();
        filename = "testFile.txt";

        B4 = new UNOCard('B', 4);
        G7 = new UNOCard('G', 7);
        R9 = new UNOCard('R', 9);

        cardContainer.addCard(B4);
        cardContainer.addCard(G7);
        cardContainer.addCard(R9);
    }

    @Test
    @DisplayName("Check that card containers are written to file correctly")
    public void checkWriteCardContainerToFile() throws FileNotFoundException, IOException{
        game.writeCardContainerToFile(cardContainer, filename);

        BufferedReader reader = new BufferedReader(new FileReader(filename));
        ArrayList<String> lines = new ArrayList<>();
        String line;
        while ((line = reader.readLine()) != null) {
            lines.add(line);
        }
        reader.close();
        assertEquals(lines.get(0), "B4");
        assertEquals(lines.get(1), "G7");
        assertEquals(lines.get(2), "R9");

        //sletter filen etter testen:
        File file = new File(filename);
        assertTrue(file.delete());
    }

    @Test
    @DisplayName("Check that card containers are read from file correctly")
    public void checkGetCardContainerFromFile() throws FileNotFoundException{
        UNOCardContainer readToCardContainer = new UNOCardContainer();

        //sjekket writeCardContainerToFile over, så bruker denne her
        game.writeCardContainerToFile(cardContainer, filename);

        game.getCardContainerFromFile(readToCardContainer, filename);

        //legger til toString() fordi hvis ikke sammenlignes de som objekt, og de er ikke samme objekt -> får false
        //ønsker å sjekke at innholdet er det samme, ikke at de er samme objekt
        assertEquals(cardContainer.toString(), readToCardContainer.toString());
    }
    
}
